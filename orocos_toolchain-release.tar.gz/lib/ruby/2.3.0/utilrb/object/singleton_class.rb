puts "WARN: no need to require 'object/singleton_class' anymore, it is built-in since Ruby 1.9"
