class Symbol
    def to_str
        to_s
    end
end
