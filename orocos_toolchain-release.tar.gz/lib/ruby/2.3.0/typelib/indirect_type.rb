module Typelib
    class IndirectType < Type
    end
end

