module Typelib
    # Base class for opaque types
    class OpaqueType < Type
    end
end


