module OroGen
    module Spec
        class Attribute < ConfigurationObject
        end
    end
end

