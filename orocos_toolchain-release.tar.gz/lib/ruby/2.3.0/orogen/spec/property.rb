module OroGen
    module Spec
        class Property < ConfigurationObject
        end
    end
end

