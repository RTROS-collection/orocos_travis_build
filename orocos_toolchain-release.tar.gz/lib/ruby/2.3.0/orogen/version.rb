module OroGen
    if !defined? ::OroGen::VERSION
        VERSION = "1.1"
    end
end

