require 'utilrb/version'

# Utilrb is yet another Ruby toolkit, in the spirit of facets. It includes all
# the standard class extensions used by www.rock-robotics.org projects.
module Utilrb
    LIB_DIR = File.expand_path(File.dirname(__FILE__))
end

