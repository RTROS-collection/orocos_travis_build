module Utilrb
    VERSION = "3.0.1"
end

